function fonction1() {
    var numero = document.getElementById("num");
    var valid = document.getElementById("validation");

    valid.style.color = "red";
    valid.style.fontSize = "15px";
    valid.style.fontFamily = "Arial";
    if (numero.value.length > 4) {
        valid.innerHTML = "numero trop longue";
    }
    else{
        valid.style.color = "green";
        valid.innerHTML = "oke";
    }
}

function fonction2(){
    var cat = document.getElementById("cat");
    var num = document.getElementById("numero");

    num.value = cat.value;
}