<?php
    $this->load->helper('url_helper');
?>
<!doctype html>
<html>
<head>
<title>User Registration Form</title>
    <link href="<?php echo site_url('assets/css/test.css') ;?>" type="text/css" rel="stylesheet" />
    <link href="<?php echo site_url('assets/css/bootstrap.min.css') ;?>" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?php  echo site_url('assets/js/first.js') ; ?>">
</script>
</head>
<body>
</div>
<form action="#" method="post">
  <select name="cat" id="cat" onchange="fonction2()">
  <?php for ($i=0; $i < count($categorie) ; $i++) { ?>
    <option value="<?php echo $categorie[$i]['numero'] ; ?>"><?php echo $categorie[$i]['nom'] ; ?></option>
  <?php }?>
  </select>
  <input type="number" name="numero" id="numero" placeholder="start with..." disabled>
  <input type="number" name="num" id="num" onkeyup="fonction1()" >
  <p id="validation"></p>
</form>
</body>
</html>